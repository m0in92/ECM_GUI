# ECM-GUI

This Python package is the lithium-ion simulator using the equivalent-circuit
model.

